classdef NaiveBayes
    methods(Static)
        % Extrai tokens únicos de uma URL
        function unique_tokens = all_UniqueTokens(urls)
            urls_lower = lower(urls);
            tokens = regexp(urls_lower, '\w+', 'match');
            tokens_str = arrayfun(@(x) string(x{:}), tokens, 'UniformOutput', false);
            unique_tokens = unique([tokens_str{:}]);
        end
        
        % Divisão em conjuntos de treino e teste
        function [trainDataset, testDataset, train_classes, test_classes] = splitTrainTestData(urls, classes, percentTrain)
            test = randperm(length(urls));
            trainSize = round(percentTrain * length(urls));
            trainIndices = test(1:trainSize); 
            testIndices = test(trainSize+1:end);
            
            trainDataset = urls(trainIndices, :);
            testDataset = urls(testIndices, :);
            train_classes = classes(trainIndices);
            test_classes = classes(testIndices);
        end
        
        % Treinamento do modelo
        function [prob_safe, prob_unsafe, words] = train(trainDataset, train_classes)
            words = NaiveBayes.all_UniqueTokens(trainDataset);
            safeCount = sum(train_classes == 'safe');
            unsafeCount = sum(train_classes == 'unsafe');
            totalTrain = length(train_classes);
            
            prob_safe = safeCount / totalTrain;
            prob_unsafe = unsafeCount / totalTrain;
        end
        
        % Predição baseada em Naive Bayes
        function predicted_classes = predict(testDataset, words, prob_safe, prob_unsafe, trainDataset, train_classes)
            predicted_classes = strings(size(testDataset));
            
            for i = 1:length(testDataset)
                ltokens = NaiveBayes.all_UniqueTokens(testDataset(i));
                logProbSafe = log(prob_safe);
                logProbUnsafe = log(prob_unsafe);
                
                for j = 1:length(ltokens)
                    token = ltokens{j};
                    indiceToken = find(strcmp(words(1,:), token));
                    
                    % Verificar se o índice está dentro dos limites
                    if ~isempty(indiceToken) && indiceToken <= length(words)
                        fprintf("\nindice = %d", indiceToken);
                        fprintf("\ntrain_ds size = %d", length(trainDataset));
                        fprintf("\ntrain_cls size = %d", length(train_classes));
                        
                        ocorrTokenSafe = sum(trainDataset(train_classes == "safe", indiceToken));
                        ocorrTokenUnsafe = sum(trainDataset(train_classes == "unsafe", indiceToken));
                        
                        probTokenSafe = (ocorrTokenSafe + 1) / (safeCount + length(words));
                        probTokenUnsafe = (ocorrTokenUnsafe + 1) / (unsafeCount + length(words));
                        
                        logProbSafe = logProbSafe + log(probTokenSafe);
                        logProbUnsafe = logProbUnsafe + log(probTokenUnsafe);
                    end
                end
                
                if logProbSafe > logProbUnsafe
                    predictedClass = "safe";
                else
                    predictedClass = "unsafe";
                end
                
                predicted_classes(i) = predictedClass;
            end
        end

    end
end


